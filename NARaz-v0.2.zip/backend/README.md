# NARaz v0.2 backend demo
Основа взята из предоставленного NAR Coin blockchain prototype и усилена под NARaz:
- max supply 1,000,000,000 NAR
- token field
- user-to-user transfers
- balance checks
- mining reward cap
- chain validation

Это демонстрационный/testnet код. Не использовать для реальных денег без криптографической подписи, P2P, защиты ключей, тестов и аудита.
