import hashlib,json,time
from dataclasses import dataclass
MAX_SUPPLY=1_000_000_000
@dataclass
class Transaction:
    sender:str; recipient:str; amount:float; token:str="NAR"; timestamp:float=0; signature:str=""
class Block:
    def __init__(self,index,transactions,previous_hash,nonce=0,timestamp=None):
        self.index=index;self.timestamp=time.time() if timestamp is None else timestamp;self.transactions=transactions;self.previous_hash=previous_hash;self.nonce=nonce;self.hash=self.calculate_hash()
    def calculate_hash(self):
        p={"index":self.index,"timestamp":self.timestamp,"transactions":self.transactions,"previous_hash":self.previous_hash,"nonce":self.nonce}
        return hashlib.sha256(json.dumps(p,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def mine(self,difficulty):
        target="0"*difficulty
        while not self.hash.startswith(target): self.nonce+=1;self.hash=self.calculate_hash()
class NARChain:
    COIN_NAME="NARaz";MAX_SUPPLY=MAX_SUPPLY;MINING_REWARD=50;DIFFICULTY=3
    def __init__(self): self.chain=[];self.pending=[];self.supply=0;self.create_genesis()
    def create_genesis(self): self.chain.append(Block(0,[{"sender":"SYSTEM","recipient":"GENESIS","amount":0,"token":"NAR","timestamp":time.time(),"signature":""}],"0").__dict__)
    def balance(self,address,token="NAR"):
        total=0.0
        for b in self.chain:
            for t in b["transactions"]:
                if t.get("token","NAR")!=token: continue
                if t["sender"]==address: total-=float(t["amount"])
                if t["recipient"]==address: total+=float(t["amount"])
        for t in self.pending:
            if t.get("token","NAR")==token and t["sender"]==address: total-=float(t["amount"])
        return round(total,8)
    def add_transaction(self,sender,recipient,amount,token="NAR",signature=""):
        amount=float(amount)
        if amount<=0: raise ValueError("Amount must be positive.")
        if sender!="SYSTEM" and amount>self.balance(sender,token): raise ValueError("Insufficient balance.")
        if token!="NAR": raise ValueError("Only NAR demo token is enabled.")
        tx={"sender":sender,"recipient":recipient,"amount":amount,"token":token,"timestamp":time.time(),"signature":signature};self.pending.append(tx);return tx
    def mine_pending(self,miner):
        if not self.pending: raise ValueError("No pending transactions.")
        reward=min(self.MINING_REWARD,self.MAX_SUPPLY-self.supply)
        txs=self.pending+[{"sender":"SYSTEM","recipient":miner,"amount":reward,"token":"NAR","timestamp":time.time(),"signature":"MINING_REWARD"}]
        b=Block(len(self.chain),txs,self.chain[-1]["hash"]);b.mine(self.DIFFICULTY);self.chain.append(b.__dict__);self.pending=[];self.supply+=reward;return b.__dict__
    def validate(self):
        for i in range(1,len(self.chain)):
            c,p=self.chain[i],self.chain[i-1]
            if c["previous_hash"]!=p["hash"]: return False
            x=Block(c["index"],c["transactions"],c["previous_hash"],c["nonce"],c["timestamp"])
            if x.calculate_hash()!=c["hash"] or not c["hash"].startswith("0"*self.DIFFICULTY): return False
        return bool(self.chain)
