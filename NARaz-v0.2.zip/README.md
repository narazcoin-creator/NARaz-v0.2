# NARaz v0.2
Минималистичный mobile-first интерфейс NARaz + demo wallet.

## Что работает в демо
- локальная регистрация пользователя;
- баланс NARaz;
- demo top-up/faucet;
- перевод X → Y;
- история операций;
- demo token list;
- настройки профиля;
- Android WebView;
- launcher icon;
- GitHub Actions для debug APK.

Backend/blockchain находится в `backend/` и основан на предоставленном NAR Coin prototype.

**Важно:** это testnet/demo. Реальные деньги, ключи и production blockchain не используются.
